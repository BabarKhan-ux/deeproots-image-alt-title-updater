
jQuery(document).ready(function($) {
    let total = 0, start = 0, limit = 10, skipped = [], updatedTotal = 0;

    $('#csv-upload-form').on('submit', function(e) {
        e.preventDefault();
        let file = $('#csv_file')[0].files[0];
        if (!file) return alert("Please upload a CSV file.");

        let formData = new FormData();
        formData.append('csv', file);
        formData.append('action', 'store_csv_data');
        formData.append('nonce', ImageAltUpdater.nonce);

        $.ajax({
            url: ImageAltUpdater.ajax_url,
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(res) {
                if (res.success) {
                    total = res.data.total;
                    $('#progress-container').show();
                    processBatch();
                } else {
                    alert("Error: " + res.data.message);
                }
            }
        });
    });

    function processBatch() {
        $.post(ImageAltUpdater.ajax_url, {
            action: 'process_image_batch',
            nonce: ImageAltUpdater.nonce,
            start: start,
            limit: limit
        }, function(res) {
            if (res.success) {
                updatedTotal += res.data.updated;
                skipped.push(...res.data.skipped);
                start += limit;
                let progress = Math.min(100, Math.round((start / total) * 100));
                $('#progress-bar').css('width', progress + '%');
                $('#progress-text').text('Progress: ' + progress + '%');

                if (start < total) {
                    processBatch();
                } else {
                    $('#result-summary').html(
                        '<p><strong>✅ ' + updatedTotal + ' images updated.</strong></p>' +
                        (skipped.length > 0 ? '<p><strong>⚠️ ' + skipped.length + ' images could not be matched.</strong><br/>Skipped URLs:<br/>' + skipped.join('<br/>') + '</p>' : '')
                    );
                }
            } else {
                alert("Error: " + res.data.message);
            }
        });
    }
});
